# Rwanda Social Security Board Data Management System (RSSBDMS)

A secure, multilingual platform built to support digital Rwanda Social Security operations and data analytics for Rwanda Social Security Board (RSSB).

## Overview

> The **Rwanda Social Security Board Data Management System (RSSBDMS)** is a secure, multilingual platform built to support digital Rwanda Social Security operations and data analytics for Rwanda Social Security Board (RSSB).

## Features

- Multilingual support (Kinyarwanda, English, French)
- Insurance policy and client management
- Data reporting and auditing
- User access control and activity logging
- Document and notification modules

## Tech Stack

- **Frontend:** React (with Tailwind CSS & shadcn/ui)
- **Backend:** Laravel
- **Database:** MySQL (with multilingual support)
- **Other:** REST API, JWT Auth, Docker (optional)

## Getting Started

Clone the repository and install dependencies.

```bash
git clone https://github.com/your-username/your-repo-name.git
cd your-repo-name
```

### Backend Setup (Laravel)

```bash
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate
php artisan serve
```

### Frontend Setup (React)

```bash
cd frontend
npm install
npm run dev
```

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Contact

**NDIHOKUBWAYO Pascal**  
Email: [ndihopascal01@gmail.com](mailto:ndihopascal01@gmail.com)  
Phone: +250788790377  
Kigali, Rwanda